# Texas Water Rate Sources: Research Report

## Executive Summary

Texas is the largest completely unserved state in the rate database (4,584 community water systems, zero coverage). The Texas Municipal League (TML) annual water and wastewater rate survey is the only identified bulk source of Texas water rate data. This report documents the TML survey's structure, accessibility, data quality, and provides a complete ingest specification. It also covers all investigated alternative Texas rate data sources.

**Key Finding:** The TML survey data is freely accessible, well-structured, and covers 237–605 Texas cities depending on the year. The 2023 survey (491 cities) is available as a downloadable XLSX file, making it the optimal starting point. Water and sewer data are published in separate files, which is ideal since our database stores water rates only.

**Estimated Impact:** Ingesting TML data across 2019–2024 would yield approximately 550–650 unique city-to-PWSID matches, covering the largest municipal systems where the majority of the Texas population lives.

---

## 1. TML Survey Structure and Format

### 1.1 What the Survey Collects

The TML survey form (publicly viewable at tml.org/FormCenter) asks each responding city for the following:

For water: the total monthly residential bill at 5,000 gallons (on a 3/4-inch meter), the total monthly commercial bill at 50,000 gallons (on a 2-inch meter), average monthly residential consumption in gallons, and total number of water customers. Earlier years (2023 and prior) also asked for residential bills at 10,000 gallons and commercial bills at 200,000 gallons; these columns were dropped in the 2024 survey.

For wastewater: the same structure — monthly residential sewer fee at 5,000 gallons and commercial sewer fee at 50,000 gallons, plus total sewer customers.

The form explicitly instructs respondents to "INCLUDE any monthly base or service fee in the total monthly costs." This means the reported figures are all-inclusive bill amounts, not disaggregated rate components (no separate base charge, volumetric rate, or tier breakpoints are captured).

### 1.2 Data Format and Access

The survey results are published on the TML website at `https://www.tml.org/229/Water-Wastewater-Survey-Results`. The page provides links to individual year results (2019–2025), each leading to downloadable files in the TML Archive Center.

**File formats available:**

The data is available as PDF for all years and as XLSX for 2017–2023. The 2024 and 2025 results are PDF-only as of this research date. The XLSX files are the preferred format for programmatic ingestion.

**Access:** No authentication is required. The files are freely downloadable without TML membership. The PDF files can even be fetched and parsed via HTTP — the text extraction yields clean, well-structured tabular data.

**URL patterns for access:**

Archive listing page: `https://www.tml.org/Archive.aspx?AMID=40` (water) — lists all years with links. Individual files: `https://www.tml.org/Archive.aspx?ADID={id}` or `https://www.tml.org/ArchiveCenter/ViewFile/Item/{id}`.

### 1.3 Year-by-Year Availability

| Year | Water Cities | WW Cities | Format | Notes |
|------|-------------|-----------|--------|-------|
| 2025 | 168 | 158 | PDF | Most recent, lowest count |
| 2024 | 237 | 239 | PDF | Good coverage, schema simplified |
| 2023 | 491 | ~473 | PDF+XLSX | **Best year for coverage** |
| 2022 | 128 | ~125 | PDF+XLSX | Low response year |
| 2021 | 593 | ~569 | PDF+XLSX | High coverage |
| 2020 | 574 | ~547 | PDF+XLSX | High coverage |
| 2019 | 605 | ~569 | PDF+XLSX | Highest response year |

The response rate varies significantly. The 2022 and 2025 surveys had notably lower participation (128 and 168 cities respectively), while 2019 and 2021 had the highest (605 and 593 cities). The reason for this variation is unclear but may relate to survey timing, follow-up effort, or competing priorities.

### 1.4 Schema Differences Between Years

A critical finding: the 2024 survey simplified its schema. The 2023 and earlier surveys included four bill columns (residential at 5,000 and 10,000 gallons, commercial at 50,000 and 200,000 gallons). The 2024 survey dropped the 10,000-gallon residential and 200,000-gallon commercial columns.

The ingest module should account for this schema variation and normalize to the common denominator (5,000 gallon residential, 50,000 gallon commercial) while preserving the 10,000-gallon data from years that include it.

---

## 2. Data Quality Assessment

### 2.1 Self-Reported, Unverified Data

TML explicitly states: "The information contained in the survey results was provided by the cities, and TML made no attempt to verify the accuracy of information reported." This means all data is self-reported and unverified.

### 2.2 Zero Values

TML uses zero to indicate "no response" — not free water/sewer. The specification states: "Where no response to a specific question was received, a zero is used to indicate no response; zeroes are not included in the computations of averages." The ingest module MUST filter out zero values rather than treating them as valid rates.

### 2.3 Data Entry Errors

Several anomalies were observed in the 2023 data. Gregory, TX appears twice — one entry shows $4,141.00 for 5,000 gallons (clearly a decimal placement error; the other entry shows the correct $41.41). Highland Park shows commercial rates of $49.34 for 50,000 gallons, which is lower than its residential rate, likely a data entry error. Manor shows $0.00 for all water fields, indicating a non-response.

### 2.4 Duplicate Entries

Multiple cities appear twice in the same year's data. In the 2023 dataset, observed duplicates include Pecos City, New Boston, Anthony, Big Lake, Cut and Shoot (with different values), and Gregory (with one erroneous entry). The 2024 data also has duplicates (Bishop appears twice with identical values). The ingest module needs deduplication logic.

### 2.5 Water-Sewer Separation

This is a strength. Water and wastewater data are in completely separate files. There is no need to decompose a combined water+sewer bill. The water file can be ingested independently for water-only rate storage.

### 2.6 Selection Bias

The survey captures self-selected respondents, not a comprehensive or random sample. Larger cities respond more consistently — Houston, the state's largest city, appears in 2023 but not 2024. The survey captures a biased (toward larger) sample of Texas cities. However, even partial coverage of the largest cities represents a significant portion of the state's population served by municipal water systems.

---

## 3. PWSID Matching Strategy

### 3.1 The Challenge

TML uses plain city names: "Houston", "Cedar Park", "North Richland Hills". Our SDWIS database uses PWS names that typically follow the pattern "CITY OF HOUSTON", "CITY OF CEDAR PARK". Texas has 4,584 CWS in SDWIS. We need to match ~237–600 TML city names to the correct PWSID.

### 3.2 Recommended Matching Approach

The matching should proceed in three phases:

**Phase 1: Normalized exact match (~70% match rate).** Uppercase the TML city name, prepend "CITY OF ", and match against `sdwis_systems.pws_name WHERE state_code = 'TX'`. Also try "TOWN OF " and "VILLAGE OF " prefixes, and try matching the raw name without prefix. Apply standard normalization: "Ft " → "Fort ", strip periods, handle compounds.

**Phase 2: Fuzzy match (~20% of remaining).** For unmatched cities, compute `fuzz.token_sort_ratio` against all TX PWS names. Accept at score ≥ 90, flag 80–89 for manual review.

**Phase 3: City-field match with population tiebreaker (~5% of remaining).** Match TML city name against `sdwis_systems.city` field. When multiple PWSIDs share the same city name, use population as a tiebreaker — TML provides city population and total customers, SDWIS has `population_served_count`. Prefer systems with `owner_type_code = 'M'` (municipal).

### 3.3 Expected Overall Match Rate

An estimated 90–95% of TML cities should match to PWSIDs. The remaining 5–10% will be cities with unusual naming, very small systems not in SDWIS, or systems where the municipal water provider has a different name than the city.

### 3.4 Supplementary Matching Data

The TWDB Water Use Survey covers ~4,700 TX public water systems with TCEQ PWS codes (equivalent to PWSIDs). Building a reference table from TWDB data (which includes city names, PWS codes, and population) would significantly improve matching accuracy. This is recommended as a preliminary step before TML ingest.

---

## 4. Other Texas Rate Data Sources Investigated

### 4.1 Public Utility Commission of Texas (PUC/PUCT)

The PUC regulates investor-owned utilities (IOUs), water supply corporations (WSCs), and utility districts. It does NOT regulate municipal systems (which are TML's domain). The PUC's FaucetFacts portal provides general information about utility rates but does not offer a downloadable rate database. Actual rate data is embedded in individual tariff filings (PDFs) within the PUC Interchange system. Extracting structured rate data would require scraping hundreds of individual docket filings — a significant engineering effort (estimated 20–40 hours).

The PUC data is complementary to TML: TML covers municipal systems, PUC covers IOUs. Together they could cover a much larger portion of TX systems. However, the PUC ingest is a Phase 2 effort due to its complexity.

### 4.2 Texas Water Development Board (TWDB)

TWDB conducts an annual Water Use Survey of ~4,700 public water systems, collecting water USE VOLUMES (gallons pumped, sold, transferred) but NOT RATES. TWDB does not collect rate or billing data. However, TWDB data is invaluable for building a TX PWS reference table with TCEQ PWS codes, population, and connection counts that can be used for PWSID matching. TWDB's Drought Management Costing Tool explicitly references TML rate data, confirming TML as the recognized primary source of TX water rate information.

### 4.3 TCEQ

The Texas Commission on Environmental Quality is the primacy agency for the Safe Drinking Water Act in Texas and maintains the master list of all public water systems. TCEQ's Drinking Water Watch (dww2.tceq.texas.gov/DWW/) has complete PWS data but no rate information. TCEQ also oversees MUD creation but does not systematically collect MUD rate data.

### 4.4 Texas Rural Water Association (TRWA)

TRWA represents rural water utilities and water supply corporations. It may conduct internal rate surveys, but no public rate data was identified. Worth investigating for Phase 3 coverage of rural systems.

### 4.5 AWWA Rate Survey

The American Water Works Association's national rate survey covers ~500 utilities across 50 states, likely including 20–40 TX systems. Behind a paywall. Minimal incremental value given TML's free and much broader TX coverage.

### 4.6 Texas Living Waters Conservation Scorecard

This NGO report (2016, 2020 editions) evaluated 356 TX utilities on conservation practices and explicitly used TML data as a primary input. It reviewed 132 utility websites for additional rate structure information. However, the Scorecard data is published as PDF assessments, not structured rate data, and offers minimal incremental value.

---

## 5. Coverage Analysis

### 5.1 What TML Covers

The TML survey covers cities that provide direct municipal water service. As of 2023 (highest-coverage year), 491 cities reported water data. These are overwhelmingly the incorporated municipalities with their own water systems — from Houston (2.3M people, 487K customers) down to tiny cities like Quintana (population 20, 31 customers).

### 5.2 What TML Does NOT Cover

TML explicitly excludes cities that provide water through Municipal Utility Districts (MUDs), inter-local agreements, or private sources. This means three major categories of Texas water systems are missing:

**Municipal Utility Districts (MUDs):** Texas has approximately 3,000 MUDs, primarily serving suburban development in the Houston and DFW metro areas. MUDs are governed by TCEQ, not city councils, and are not TML members. MUDs serve millions of Texans but have no known bulk rate data source.

**Water Supply Corporations (WSCs):** Member-owned non-profit water providers serving rural communities. Regulated by PUC for rate changes. Hundreds of WSCs exist across Texas with no known centralized rate database.

**Investor-Owned Utilities (IOUs):** Companies like Aqua Texas, SouthWest Water Company. Regulated by PUC. Rate data exists in individual tariff filings but is not centralized.

### 5.3 Population Coverage Estimate

Despite covering only 491–605 out of 4,584 CWS (11–13% by system count), TML data likely captures 60–70% of the Texas population served by municipal water. This is because the largest cities (Houston, San Antonio, Dallas, Austin, Fort Worth — though not all appear every year) have millions of residents each. The 50 largest Texas cities alone serve over 15 million people.

---

## 6. Recommended Implementation Plan

### 6.1 Phase 1: TML Ingest (Immediate, 4–6 hours)

Download the 2023 XLSX file (491 cities). Parse with pandas. Deduplicate (keep first occurrence). Filter zero values. Fuzzy-match city names to PWSIDs. Store water bill amounts at 5,000 and 10,000 gallon levels. Then ingest 2024 PDF data for any cities not already covered by 2023. Optionally union with 2019–2021 for maximum unique-city coverage.

### 6.2 Phase 2: TWDB Metadata Import (2–3 hours)

Build a TX PWS reference table from TWDB Water Use Survey data. This provides TCEQ PWS codes, city names, population, and connection counts for all ~4,700 TX public water systems. Use this as the matching backbone for TML and any future TX rate sources.

### 6.3 Phase 3: PUC IOU Tariff Scraping (20–40 hours)

For broader coverage, scrape individual tariff filings from the PUC Interchange for investor-owned utilities. This captures rate structure details (tiers, base charges) not available from TML, but requires significant development effort.

### 6.4 Multi-Year Union Strategy

For maximum coverage, the ingest module should support combining data across multiple TML survey years. Logic: for each unique city, take the most recent year's rates. This could yield 650+ unique cities from the 2019–2024 period, maximizing coverage without sacrificing currency.

---

## 7. Key Findings for the Claude Code Session

The Claude Code session building the ingest module should know:

1. **Start with the 2023 XLSX file** (ADID=206). It has 491 cities and a clean tabular format. If XLSX download doesn't work, fall back to PDF parsing — the PDF text extraction is remarkably clean.

2. **Water and sewer are separate files.** Only ingest the water file. Ignore wastewater unless the database schema supports it.

3. **Zero = missing data.** Filter out any row where the 5,000-gallon fee is $0.00.

4. **Deduplicate cities.** Some cities appear twice. Keep the row with non-zero values or the first occurrence.

5. **Schema varies by year.** 2024+ has only 5,000-gal residential and 50,000-gal commercial. 2023 and earlier also have 10,000-gal residential and 200,000-gal commercial.

6. **City names are clean.** Plain mixed-case names like "Houston", "Cedar Park", "North Richland Hills". No "CITY OF" prefix. This simplifies the matching — just prepend "CITY OF " and uppercase for SDWIS matching.

7. **The WV PSC ingest module is the closest template.** Both use name matching + bill amounts without PWSIDs. The fuzzy matching approach applies directly.

8. **All data URLs are in `tml_ingest_spec.yaml`.** No additional web research should be needed.
